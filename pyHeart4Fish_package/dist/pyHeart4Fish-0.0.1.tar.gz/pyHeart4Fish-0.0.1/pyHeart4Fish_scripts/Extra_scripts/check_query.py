import os


# print(os.system("py"))
print(os.popen('py').read())
